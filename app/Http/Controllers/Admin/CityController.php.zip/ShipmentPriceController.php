<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Shipment;
use App\Models\ShipmentPrice;
use App\Models\ShipmentZone;
use Datatables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Validator;

class ShipmentPriceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    //*** JSON Request
    public function datatables()
    {
         $datas = ShipmentPrice::all();
         //--- Integrating This Collection Into Datatables
         return Datatables::of($datas)
                            ->editColumn('value', function(ShipmentPrice $data) {
                                $sign = Currency::where('is_default','=',1)->first();
                                $price = $sign->sign . ($data->value * $sign->value);
                                return  $price;
                            }) ->editColumn('extra', function(ShipmentPrice $data) {
                                $sign = Currency::where('is_default','=',1)->first();
                                $pricee = $sign->sign . ($data->extra * $sign->value);
                                return  $pricee;
                            })->editColumn('shipment_id', function(ShipmentPrice $data) {
                               $shipments = Shipment::where('id',$data->shipment_id)->first();
                                $shipment = !empty($shipments) ? $shipments->name : "company deleted" ;
                                return  $shipment;
                            })->editColumn('to', function(ShipmentPrice $data) {
                               $shipmentss = ShipmentZone::where('id',$data->to)->first();
                                $zone = !empty($shipmentss) ? $shipmentss->name : "Zone deleted" ;
                                return  $zone;
                            })
                            ->addColumn('action', function(ShipmentPrice $data) {
                                return '<div class="action-list"><a data-href="' . route('admin-shipment-price-edit',$data->id) . '" class="edit" data-toggle="modal" data-target="#modal1"> <i class="fas fa-edit"></i>Edit</a><a href="javascript:;" data-href="' . route('admin-shipment-price-delete',$data->id) . '" data-toggle="modal" data-target="#confirm-delete" class="delete"><i class="fas fa-trash-alt"></i></a></div>';
                            }) 
                            ->rawColumns(['action'])
                            ->toJson(); //--- Returning Json Data To Client Side
    }

    //*** GET Request
    public function index()
    {
        return view('admin.shipmentprice.index');
    }

    //*** GET Request
    public function create()
    {
        $sign = Currency::where('is_default','=',1)->first();
        $shipments = Shipment::all();
        $zones = ShipmentZone::all();
        return view('admin.shipmentprice.create',compact('shipments','zones'));
    }

    //*** POST Request
    public function store(Request $request)
    {
        //--- Validation Section
      
        //--- Validation Section Ends

        //--- Logic Section
        $data = new ShipmentPrice();
        $input = $request->all();
        $data->fill($input)->save();
        //--- Logic Section Ends

        //--- Redirect Section        
        $msg = 'New Data Added Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends    
    }

    //*** GET Request
    public function edit($id)
    {
        $shipments = Shipment::all();
        $data = ShipmentPrice::findOrFail($id);
         $zones = ShipmentZone::all();
        return view('admin.shipmentprice.edit',compact('data','shipments','zones'));
    }

    //*** POST Request
    public function update(Request $request, $id)
    {
        //--- Validation Section
       
        //--- Validation Section Ends

        //--- Logic Section
        $data = ShipmentPrice::findOrFail($id);
        $input = $request->all();
        $data->update($input);
        //--- Logic Section Ends

        //--- Redirect Section     
        $msg = 'Data Updated Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends            
    }

    //*** GET Request Delete
    public function destroy($id)
    {
        $data = ShipmentPrice::findOrFail($id);
        $data->delete();
        //--- Redirect Section     
        $msg = 'Data Deleted Successfully.';
        return response()->json($msg);      
        //--- Redirect Section Ends     
    }
}
